package Lab3;

import java.util.Scanner;

import Lab2.Direccion;
import Lab2.Fecha;
import Lab2.Usuario;

public class PrincipalCagarUsuarios {

	public static void main(String[] args) {
		Agenda agenda = new Agenda(5);
		// Usuario 1
		Fecha fecha_nacimiento = new Fecha(Short.valueOf("02"), Short.valueOf("01"), Short.valueOf("2002"));
		Direccion direccion_residencia = new Direccion("calle66", "66-66", "VillaHermosa", "Medellín", null, null);
		Usuario usuario = new Usuario("Alejandro Giraldo Quiceno", 1000753146L, fecha_nacimiento, "Medellin",
				3053080620L, "algiraldoq@unal.edu.co", direccion_residencia);
		agenda.Agregar(usuario);

		// Usuario 2
//		fecha_nacimiento = new Fecha(Short.valueOf("02"), Short.valueOf("01"), Short.valueOf("2002"));
//		direccion_residencia = new Direccion("calle66", "66-66", "VillaHermosa", "Medellín", null, null);
//		usuario = new Usuario("Alejandro Giraldo Quiceno", 1000753146L, fecha_nacimiento, "Medellin",
//				3053080620L, "algiraldoq@unal.edu.co", direccion_residencia);
//		agenda.Agregar(usuario);

		// Usuario 3
//		fecha_nacimiento = new Fecha(Short.valueOf("02"), Short.valueOf("01"), Short.valueOf("2002"));
//		direccion_residencia = new Direccion("calle66", "66-66", "VillaHermosa", "Medellín", null, null);
//		usuario = new Usuario("Alejandro Giraldo Quiceno", 1000753146L, fecha_nacimiento, "Medellin",
//				3053080620L, "algiraldoq@unal.edu.co", direccion_residencia);
//		agenda.Agregar(usuario);

		// Usuario 4
//		fecha_nacimiento = new Fecha(Short.valueOf("02"), Short.valueOf("01"), Short.valueOf("2002"));
//		direccion_residencia = new Direccion("calle66", "66-66", "VillaHermosa", "Medellín", null, null);
//		usuario = new Usuario("Alejandro Giraldo Quiceno", 1000753146L, fecha_nacimiento, "Medellin",
//				3053080620L, "algiraldoq@unal.edu.co", direccion_residencia);
//		agenda.Agregar(usuario);

		// Usuario 5
//		fecha_nacimiento = new Fecha(Short.valueOf("02"), Short.valueOf("01"), Short.valueOf("2002"));
//		direccion_residencia = new Direccion("calle66", "66-66", "VillaHermosa", "Medellín", null, null);
//		usuario = new Usuario("Alejandro Giraldo Quiceno", 1000753146L, fecha_nacimiento, "Medellin",
//				3053080620L, "algiraldoq@unal.edu.co", direccion_residencia);
//		agenda.Agregar(usuario);

		Scanner myobj = new Scanner(System.in);
		System.out.println("Ingrese Id que desea buscar:");
		String strId = myobj.nextLine();
		Long id = Long.valueOf(strId);
		Integer posicion = agenda.Buscar(id);
		System.out.println("La posicion de ese usuario es:" + posicion);
		agenda.Tofile();
		myobj.close();
	}

}
